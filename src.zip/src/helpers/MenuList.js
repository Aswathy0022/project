import bread from "../assets/assests/bread[115].jpg";
import burger from "../assets/assests/burger[116].jpg";
import caramel from "../assets/assests/caramel[118].jpg";
import cheesyBread from "../assets/assests/cheesyBread[119].jpg";
import pastha from "../assets/assests/pastha[128].jpg";
import juice from "../assets/assests/juice[126].jpg";



export const MenuList = [
  {
    name: "Biscoff stuffed french toast",
    image: bread,
    price: 15.99,
  },
  {
    name: "stuffed cheese burger",
    image: burger,
    price: 11.99,
  },
  {
    name: "caramal coffee",
    image:caramel,
    price: 256.53,
  },
  {
    name: "cheesyBread",
    image: cheesyBread,
    price: 17.99,
  },
  {
    name: " cheesy pastha",
    image:pastha,
    price: 4.99,
  },
  {
    name: "pomegranate juice",
    image: juice,
    price: 1997.99,
  },


];